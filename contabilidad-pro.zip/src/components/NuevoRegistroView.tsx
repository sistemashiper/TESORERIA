import React, { useState } from 'react';
import { 
  Plus, 
  FileText, 
  Banknote, 
  Users, 
  Calendar, 
  Receipt, 
  Info, 
  Check, 
  TrendingUp, 
  AlertTriangle 
} from 'lucide-react';
import { Client, TransactionType } from '../types';

interface NuevoRegistroViewProps {
  clients: Client[];
  onCancel: () => void;
  onSave: (transactionData: {
    type: TransactionType;
    clientId: string;
    amount: number;
    date: string;
    reference: string;
    description: string;
    isUrgente: boolean;
  }) => void;
}

export default function NuevoRegistroView({ clients, onCancel, onSave }: NuevoRegistroViewProps) {
  const [type, setType] = useState<TransactionType>('factura');
  const [clientId, setClientId] = useState(clients[0]?.id || '');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  
  // Dynamic default folios based on transaction types
  const [reference, setReference] = useState('');
  const [description, setDescription] = useState('');
  const [isUrgente, setIsUrgente] = useState(false);
  const [currency, setCurrency] = useState('MXN');

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Set nice default folios on toggle
  const handleTypeToggle = (selectedType: TransactionType) => {
    setType(selectedType);
    if (selectedType === 'factura') {
      setReference(`F-2024-${Math.floor(100 + Math.random() * 900)}`);
    } else {
      setReference(`ANT-${Math.floor(1000 + Math.random() * 9000)}`);
    }
  };

  // Initialize correct prefilled folio
  React.useEffect(() => {
    handleTypeToggle(type);
  }, []);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId || !amount || !reference) return;

    setIsSubmitting(true);
    setTimeout(() => {
      onSave({
        type,
        clientId,
        amount: parseFloat(amount),
        date,
        reference,
        description,
        isUrgente: type === 'factura' ? isUrgente : false
      });
      setIsSubmitting(false);
    }, 1200);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="font-sans font-black text-2xl text-slate-900 tracking-tight">Nuevo Registro Financiero</h2>
          <p className="text-sm text-slate-500 mt-1">Cargue pólizas de cobros recibidos (anticipos) o cargos emitidos (facturas) al sistema.</p>
        </div>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-800 rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
          >
            Cancelar
          </button>
          
          <button
            onClick={handleFormSubmit}
            disabled={isSubmitting || !amount || !reference || !clientId}
            className="px-5 py-2.5 bg-black text-white hover:bg-slate-900 disabled:opacity-40 rounded-xl text-xs font-bold uppercase tracking-wider shadow-sm transition-all flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <svg className="animate-spin h-3.5 w-3.5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Registrando...</span>
              </>
            ) : (
              <span>Guardar Registro</span>
            )}
          </button>
        </div>
      </div>

      <form onSubmit={handleFormSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Main form grid - 8 columns */}
        <div className="lg:col-span-8 space-y-6">
          
          <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-6">
            
            {/* Toggle switch selectors between Factura and Anticipo */}
            <div className="space-y-2">
              <label className="block text-[10px] font-bold text-slate-500 tracking-wider uppercase px-0.5">Tipo de Registro</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => handleTypeToggle('factura')}
                  className={`py-4 rounded-xl border flex items-center justify-center gap-2.5 font-sans font-bold text-xs uppercase tracking-wider transition-all duration-200 ${
                    type === 'factura' 
                      ? 'bg-black text-white border-black shadow-md' 
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100/60'
                  }`}
                >
                  <FileText className="w-4.5 h-4.5" />
                  Factura de Cargo
                </button>
                <button
                  type="button"
                  onClick={() => handleTypeToggle('anticipo')}
                  className={`py-4 rounded-xl border flex items-center justify-center gap-2.5 font-sans font-bold text-xs uppercase tracking-wider transition-all duration-200 ${
                    type === 'anticipo' 
                      ? 'bg-black text-white border-black shadow-md' 
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100/60'
                  }`}
                >
                  <Banknote className="w-4.5 h-4.5" />
                  Anticipo Recibido
                </button>
              </div>
            </div>

            {/* Inputs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 font-sans">
              
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-500 tracking-wider uppercase px-0.5">Asignar Cliente</label>
                <div className="relative">
                  <select
                    value={clientId}
                    onChange={(e) => setClientId(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs font-bold text-slate-800 uppercase tracking-wider outline-none focus:ring-4 focus:ring-slate-100 focus:border-black cursor-pointer"
                  >
                    {clients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.id})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-500 tracking-wider uppercase px-0.5">Folio / Referencia</label>
                <input
                  type="text"
                  required
                  placeholder={type === 'factura' ? 'F-2024-XXX' : 'ANT-XXXX'}
                  value={reference}
                  onChange={(e) => setReference(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs font-bold font-mono text-slate-800 outline-none focus:ring-4 focus:ring-slate-100 focus:border-black transition-all"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-500 tracking-wider uppercase px-0.5">Moneda</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCurrency('MXN')}
                    className={`py-3 rounded-lg text-xs font-bold transition-all border ${currency === 'MXN' ? 'bg-slate-100 border-slate-350 text-slate-900': 'bg-transparent border-slate-100 text-slate-400'}`}
                  >
                    MXN ($)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrency('USD')}
                    className={`py-3 rounded-lg text-xs font-bold transition-all border ${currency === 'USD' ? 'bg-slate-100 border-slate-350 text-slate-900': 'bg-transparent border-slate-100 text-slate-400'}`}
                  >
                    USD ($)
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-500 tracking-wider uppercase px-0.5">Monto Total</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 font-sans font-extrabold text-sm text-slate-400">$</span>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 pl-8 text-sm font-bold font-mono text-slate-800 outline-none focus:ring-4 focus:ring-slate-100 focus:border-black transition-all"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-500 tracking-wider uppercase px-0.5">Fecha de Emisión</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs text-slate-800 font-bold uppercase transition-all"
                />
              </div>

              <div className="md:col-span-2 space-y-1">
                <label className="block text-[10px] font-bold text-slate-500 tracking-wider uppercase px-0.5">Concepto / Descripción</label>
                <textarea
                  placeholder="Descripción detallada de la operación o flete..."
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm outline-none focus:ring-4 focus:ring-slate-100 focus:border-black transition-all resize-none text-slate-800 placeholder-slate-400 font-medium"
                />
              </div>

            </div>

            {/* Invoices-only specialized options */}
            {type === 'factura' && (
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between font-sans">
                <div className="space-y-0.5">
                  <label className="text-xs font-bold text-slate-900 uppercase tracking-tight">Marcar como urgente o vencido</label>
                  <p className="text-[11px] text-slate-400 font-medium">Asigna prioridad visual crítica en tableros y auditoría AI.</p>
                </div>
                <div className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="urgent-toggle"
                    className="sr-only peer"
                    checked={isUrgente}
                    onChange={(e) => setIsUrgente(e.target.checked)}
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-slate-900"></div>
                </div>
              </div>
            )}

          </div>
        </div>

        {/* Advisory Sidebar info - 4 columns */}
        <div className="lg:col-span-4 space-y-6">
          
          <div className="bg-slate-100/70 border border-slate-200 p-6 rounded-2xl shadow-inner text-slate-700 h-fit space-y-4">
            <h4 className="font-sans font-bold text-[10px] uppercase tracking-wider text-slate-400 flex items-center gap-1.5 leading-none">
              <Info className="w-4 h-4 text-slate-400" />
              Resumen de Registro
            </h4>
            
            <div className="space-y-4 font-sans text-xs">
              <div className="flex justify-between items-center border-b border-slate-200/50 pb-2">
                <span className="font-bold text-slate-500 uppercase tracking-widest text-[9px]">EMISOR ACTIVO</span>
                <span className="text-slate-900 font-extrabold uppercase">CORPORATIVO_01</span>
              </div>
              <div className="flex justify-between items-center border-b border-slate-200/50 pb-2">
                <span className="font-bold text-slate-500 uppercase tracking-widest text-[9px]">CLASIFICACIÓN SAT</span>
                <span className="text-slate-900 font-extrabold uppercase">81111508 / SERVICIOS</span>
              </div>
              <div className="p-3 bg-white border border-slate-200/80 rounded-xl leading-relaxed text-[11px] font-medium text-slate-500">
                {type === 'factura' ? (
                  'Las facturas pendientes aumentarán el saldo bruto por cobrar del cliente de inmediato. Se ordenarán por antigüedad en la secuencia de conciliación automática.'
                ) : (
                  'Los anticipos registrados quedarán congelados como crédito disponible listo para liquidarse contra las facturas correspondientes según el criterio FIFO.'
                )}
              </div>
            </div>
          </div>

          <div className="rounded-2xl overflow-hidden shadow-sm aspect-video border border-slate-200">
            <img 
              alt="Register Visualizer Graphic" 
              className="w-full h-full object-cover"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDFXWvVnSjT7V-R-1lIs0Z6N8S3g4M6nLzZ6X6S7g4U6P7R8D-yR7V7L7Z8"
            />
          </div>

        </div>

      </form>
    </div>
  );
}
