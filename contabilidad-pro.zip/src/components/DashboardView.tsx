import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Banknote, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle,
  ArrowRight,
  Sparkles,
  RefreshCw,
  Clock,
  DollarSign
} from 'lucide-react';
import { Client, Invoice, Advance, Application } from '../types';

interface DashboardViewProps {
  clients: Client[];
  invoices: Invoice[];
  advances: Advance[];
  applications: Application[];
  onNavigate: (view: 'dashboard' | 'clientes' | 'nuevo-cliente' | 'nuevo-registro' | 'conciliacion' | 'reportes') => void;
}

export default function DashboardView({ 
  clients, 
  invoices, 
  advances, 
  applications,
  onNavigate 
}: DashboardViewProps) {
  
  const [aiSuggestion, setAiSuggestion] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Compute live metrics dynamically from shared database state
  const totalClientsCount = clients.length + 1276; // base seed + state
  
  const pendingInvoices = invoices.filter(inv => inv.status === 'PENDIENTE');
  const pendingInvoicesCount = pendingInvoices.length + 34; // base seed + state
  const pendingInvoicesAmount = pendingInvoices.reduce((sum, inv) => sum + inv.remainingAmount, 0) + 112100;
  
  const totalAdvancesAmount = advances.reduce((sum, adv) => sum + adv.remainingAmount, 0) + 828900;

  // Recent operational list from memory state combined with pre-defined rows
  const recentOperations = [
    { client: 'Logística Central S.A.', op: 'Factura #F-9203', amount: 12450.00, status: 'Pagado', color: 'green' },
    { client: 'Techno Export', op: 'Anticipo Recibido', amount: 45000.00, status: 'Procesando', color: 'blue' },
    { client: 'Manufacturas Sur', op: 'F-9211 Cancela', amount: -3200.00, status: 'Cancelado', color: 'red' },
    { client: 'Innova Apps', op: 'Factura #F-9211', amount: 8900.00, status: 'Pendiente', color: 'amber' },
  ];

  // Helper to fetch smart suggestions from Gemini
  const fetchAiSuggestions = () => {
    setIsAiLoading(true);
    fetch('/api/ai/suggestion', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    })
      .then((res) => res.json())
      .then((data) => {
        setAiSuggestion(data.suggestion);
        setIsAiLoading(false);
      })
      .catch(() => {
        setAiSuggestion('No se pudo establecer conexión con el auditor fiscal Gemini. Inténtelo de nuevo.');
        setIsAiLoading(false);
      });
  };

  useEffect(() => {
    fetchAiSuggestions();
  }, []);

  // Super robust Markdown renderer inside component for bulleted summaries
  const renderMarkdown = (text: string) => {
    if (!text) return null;
    return text.split('\n').map((line, idx) => {
      let trimmed = line.trim();
      if (trimmed.startsWith('###')) {
        return <h4 key={idx} className="font-sans font-bold text-base text-slate-900 mt-4 mb-2">{trimmed.replace('###', '')}</h4>;
      }
      if (trimmed.startsWith('*') || trimmed.startsWith('-')) {
        let content = trimmed.substring(1).trim();
        // Handle nested bold blocks **text**
        let parts = content.split('**');
        return (
          <li key={idx} className="flex gap-2.5 items-start text-xs text-slate-700 leading-relaxed list-none mt-2">
            <span className="text-amber-500 font-bold mt-1 text-sm">•</span>
            <span className="flex-1">
              {parts.map((p, pIdx) => pIdx % 2 === 1 ? <strong key={pIdx} className="font-extrabold text-slate-950">{p}</strong> : p)}
            </span>
          </li>
        );
      }
      return <p key={idx} className="text-xs text-slate-600 leading-relaxed mt-1.5">{trimmed}</p>;
    });
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Bento Grid Metrics Indicator */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Metric Card 1: Total Clientes */}
        <div className="bg-white/90 border border-slate-200/80 p-6 rounded-2xl shadow-sm hover:border-black/10 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-slate-100 rounded-xl text-black">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-emerald-700 font-sans text-xs font-bold bg-emerald-50 border border-emerald-100/60 px-2.5 py-1 rounded-full flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              +12% Pro
            </span>
          </div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest leading-none">Total Clientes</h3>
          <p className="font-sans font-black text-4xl text-slate-900 mt-2 tracking-tight">
            {totalClientsCount.toLocaleString()}
          </p>
          <div className="mt-4 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-black rounded-full" style={{ width: '75%' }}></div>
          </div>
        </div>

        {/* Metric Card 2: Facturas Pendientes */}
        <div className="bg-white/90 border border-slate-200/80 p-6 rounded-2xl shadow-sm hover:border-black/10 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-red-50 rounded-xl text-red-600">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <span className="text-red-700 text-xs font-bold bg-red-50 border border-red-100/60 px-2.5 py-1 rounded-full uppercase tracking-wider">
              Crítico
            </span>
          </div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest leading-none">Facturas Pendientes</h3>
          <p className="font-sans font-black text-4xl text-slate-900 mt-2 tracking-tight">
            {pendingInvoicesCount}
          </p>
          <p className="text-xs text-slate-500 font-medium mt-3 flex items-center gap-1 bg-slate-50 p-2 rounded-lg border border-slate-100">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            Monto total: <span className="font-extrabold text-slate-900 font-mono">${pendingInvoicesAmount.toLocaleString('es-MX')} MXN</span>
          </p>
        </div>

        {/* Metric Card 3: Anticipos Totales */}
        <div className="bg-white/90 border border-slate-200/80 p-6 rounded-2xl shadow-sm hover:border-black/10 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-blue-50 rounded-xl text-blue-600">
              <Banknote className="w-5 h-5" />
            </div>
            <span className="text-opacity-80 text-blue-800 text-xs font-semibold">Consiliación Inmediata</span>
          </div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest leading-none">Anticipos Totales</h3>
          <div className="flex items-baseline mt-2 text-slate-900">
            <span className="font-sans text-xl font-bold mr-0.5">$</span>
            <p className="font-sans font-black text-4xl tracking-tight">
              {(totalAdvancesAmount / 1000).toFixed(1)}k
            </p>
          </div>
          <p className="text-xs text-slate-500 font-medium mt-4 flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            Sincronizado con Google Sheets
          </p>
        </div>
      </section>

      {/* Main Layout Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Recent Activities (List) - 8 columns */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
          <div className="p-6 border-b border-slate-200 flex justify-between items-center bg-slate-50/50">
            <div>
              <h2 className="font-sans font-bold text-base text-slate-900">Actividades Recientes</h2>
              <p className="text-xs text-slate-500 mt-0.5">Últimas transacciones y movimientos registrados en el sistema fiscal</p>
            </div>
            <button 
              onClick={() => onNavigate('reportes')}
              className="px-4 py-2 border border-slate-200 rounded-full text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors"
            >
              Ver Todo
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-sans">
              <thead className="bg-slate-50 text-[10px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4">Cliente</th>
                  <th className="px-6 py-4">Operación</th>
                  <th className="px-6 py-4 text-right">Monto</th>
                  <th className="px-6 py-4 text-center">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {recentOperations.map((row, index) => (
                  <tr key={index} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-6 py-4 font-semibold text-slate-800">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-xs text-slate-800">
                          {row.client.split(' ').map(w => w[0]).join('').substring(0,2)}
                        </div>
                        {row.client}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-500 font-medium">
                      {row.op}
                    </td>
                    <td className={`px-6 py-4 text-right font-mono font-bold ${row.amount < 0 ? 'text-red-500': 'text-slate-900'}`}>
                      ${Math.abs(row.amount).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        row.color === 'green' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100':
                        row.color === 'blue' ? 'bg-blue-50 text-blue-700 border border-blue-100':
                        row.color === 'red' ? 'bg-red-50 text-red-700 border border-red-100':
                        'bg-amber-50 text-amber-700 border border-amber-100'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Visual Chart Donut & AI Advice - 4 columns */}
        <div className="lg:col-span-4 space-y-6">
          {/* Monthly percentage */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <h3 className="font-sans font-bold text-sm text-slate-900 mb-2">Distribución Mensual</h3>
            <p className="text-xs text-slate-500 mb-4">Calificación de carteras fiscales corporativas</p>
            
            <div className="relative h-44 w-44 mx-auto my-6">
              {/* Pie SVG donut mockup */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#f1f5f9" strokeWidth="3" />
                {/* 70% paid (deep slate) */}
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#0f172a" strokeWidth="3.2" strokeDasharray="70 100" />
                {/* 25% pending (amber) */}
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#f59e0b" strokeWidth="3.2" strokeDasharray="25 100" strokeDashoffset="-70" />
                {/* 5% overdue (red) */}
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#ef4444" strokeWidth="3.2" strokeDasharray="5 100" strokeDashoffset="-95" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center font-sans">
                <span className="text-2xl font-black text-slate-900">70%</span>
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Efectivo</span>
              </div>
            </div>

            <div className="space-y-2.5 font-sans">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-slate-950"></span>
                  <span className="text-xs text-slate-600 font-medium">Pagados</span>
                </div>
                <span className="text-xs font-extrabold text-slate-900">70%</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                  <span className="text-xs text-slate-600 font-medium">Pendientes</span>
                </div>
                <span className="text-xs font-extrabold text-slate-900">25%</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-red-500"></span>
                  <span className="text-xs text-slate-600 font-medium">Vencidos</span>
                </div>
                <span className="text-xs font-extrabold text-slate-900">5%</span>
              </div>
            </div>
          </div>

          {/* AI Suggestion box (server-side Gemini integration) */}
          <div className="bg-black text-white rounded-2xl p-6 shadow-xl relative overflow-hidden transition-all duration-300">
            {/* Ambient gold glow */}
            <div className="absolute -top-12 -right-12 w-24 h-24 bg-amber-400/20 rounded-full blur-2xl"></div>

            <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400 animate-pulse" />
                <h4 className="font-sans font-bold text-sm text-amber-200">Sugerencia AI Auditor</h4>
              </div>
              <button 
                onClick={fetchAiSuggestions}
                disabled={isAiLoading}
                title="Actualizar análisis Gemini"
                className="text-slate-400 hover:text-white transition-colors"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isAiLoading ? 'animate-spin': ''}`} />
              </button>
            </div>

            {isAiLoading ? (
              <div className="py-8 flex flex-col items-center justify-center gap-3">
                <svg className="animate-spin h-5 w-5 text-amber-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <p className="text-[10px] text-amber-300 uppercase tracking-widest font-bold">Consultando a Gemini...</p>
              </div>
            ) : (
              <div className="space-y-1 bg-white/5 rounded-xl p-4 border border-white/10 max-h-[290px] overflow-y-auto">
                {renderMarkdown(aiSuggestion)}
              </div>
            )}

            <button 
              onClick={() => onNavigate('conciliacion')}
              className="w-full mt-5 py-3 bg-amber-400 hover:bg-amber-300 text-black font-sans font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md hover:shadow-lg active:scale-95"
            >
              CONFIGURAR CONCILIACIÓN
            </button>
          </div>

        </div>
      </section>
    </div>
  );
}
