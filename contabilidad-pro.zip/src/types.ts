export type ClientCategory = 'Corporativo' | 'Pyme' | 'Persona Física' | 'Gobierno';

export interface Client {
  id: string; // e.g., "C-40912"
  name: string;
  rfc: string;
  category: ClientCategory;
  address: string;
  phone: string;
  email: string;
  saldoPendiente: number;
  estadoSaldo: 'Al Corriente' | 'Saldo Vencido' | 'En Revisión';
  ultimoPago: string;
  createdAt: string;
}

export type TransactionType = 'factura' | 'anticipo';
export type TransactionStatus = 'PENDIENTE' | 'PAGADO' | 'CANCELADO' | 'DISPONIBLE' | 'APLICADO' | 'PROCESANDO';

export interface Invoice {
  id: string; // e.g., "F-2024-001"
  clientId: string;
  clientName: string;
  reference: string;
  amount: number;
  remainingAmount: number;
  date: string; //YYYY-MM-DD
  status: 'PENDIENTE' | 'PAGADO' | 'CANCELADO';
  description: string;
  isUrgente: boolean;
}

export interface Advance {
  id: string; // e.g., "ANT-1022"
  clientId: string;
  clientName: string;
  reference: string;
  amount: number; // Original amount
  remainingAmount: number; // Unapplied amount
  date: string; // YYYY-MM-DD
  status: 'DISPONIBLE' | 'APLICADO' | 'PROCESANDO';
  description: string;
}

export interface Application {
  id: string;
  invoiceId: string;
  invoiceReference: string;
  advanceId: string;
  advanceReference: string;
  clientName: string;
  amountApplied: number;
  date: string;
}

export interface DashboardMetrics {
  totalClients: number;
  pendingInvoicesCount: number;
  pendingInvoicesAmount: number;
  totalAdvancesAmount: number;
  recentActivities: {
    clientName: string;
    type: string;
    amount: number;
    status: string;
    date: string;
  }[];
}

export interface User {
  email: string;
  role: string;
  name: string;
}

export type ViewType = 'dashboard' | 'clientes' | 'nuevo-cliente' | 'nuevo-registro' | 'conciliacion' | 'reportes';

