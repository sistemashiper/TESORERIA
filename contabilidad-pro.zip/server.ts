import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { Client, Invoice, Advance, Application } from './src/types';
import { initialClients, initialInvoices, initialAdvances, initialApplications } from './src/initialData';

// Persistent-in-memory states
let clientsState: Client[] = [...initialClients];
let invoicesState: Invoice[] = [...initialInvoices];
let advancesState: Advance[] = [...initialAdvances];
let applicationsState: Application[] = [...initialApplications];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Auth endpoint
  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    if (email === 'admin@corporativo.com' && password) {
      res.json({
        success: true,
        user: {
          email: 'admin@corporativo.com',
          name: 'Admin Usuario',
          role: 'Administrador'
        }
      });
    } else {
      res.status(401).json({ success: false, error: 'Credenciales inválidas.' });
    }
  });

  // Full database fetch
  app.get('/api/database', (req, res) => {
    res.json({
      clients: clientsState,
      invoices: invoicesState,
      advances: advancesState,
      applications: applicationsState,
    });
  });

  // Create client
  app.post('/api/clients', (req, res) => {
    const { name, rfc, category, address, phone, email } = req.body;
    if (!name || !rfc) {
      return res.status(400).json({ error: 'Nombre y RFC son obligatorios.' });
    }

    const newId = `C-${Math.floor(10000 + Math.random() * 90000)}`;
    const newClient: Client = {
      id: newId,
      name,
      rfc,
      category: category || 'Corporativo',
      address: address || '',
      phone: phone || '',
      email: email || '',
      saldoPendiente: 0,
      estadoSaldo: 'Al Corriente',
      ultimoPago: 'Hoy, Registro',
      createdAt: new Date().toISOString().split('T')[0]
    };

    clientsState.unshift(newClient);
    res.status(201).json(newClient);
  });

  // Create dynamic registers (Invoice or Advance)
  app.post('/api/transactions', (req, res) => {
    const { type, clientId, amount, date, reference, description, isUrgente } = req.body;
    if (!clientId || !amount || !reference) {
      return res.status(400).json({ error: 'Cliente, Monto y Referencia son obligatorios.' });
    }

    const client = clientsState.find(c => c.id === clientId);
    if (!client) {
      return res.status(404).json({ error: 'Cliente no encontrado.' });
    }

    const numericAmount = parseFloat(amount);

    if (type === 'factura') {
      const newInvoice: Invoice = {
        id: reference,
        clientId,
        clientName: client.name,
        reference,
        amount: numericAmount,
        remainingAmount: numericAmount,
        date: date || new Date().toISOString().split('T')[0],
        status: 'PENDIENTE',
        description: description || '',
        isUrgente: !!isUrgente
      };
      invoicesState.unshift(newInvoice);
      
      // Update client pending balance
      client.saldoPendiente += numericAmount;
      if (client.estadoSaldo === 'Al Corriente') {
        client.estadoSaldo = 'En Revisión';
      }
      
      res.status(201).json({ type: 'factura', transaction: newInvoice });
    } else {
      const newAdvance: Advance = {
        id: reference,
        clientId,
        clientName: client.name,
        reference,
        amount: numericAmount,
        remainingAmount: numericAmount,
        date: date || new Date().toISOString().split('T')[0],
        status: 'DISPONIBLE',
        description: description || ''
      };
      advancesState.unshift(newAdvance);
      res.status(201).json({ type: 'anticipo', transaction: newAdvance });
    }
  });

  // Execute FIFO reconciliation for a selected client
  app.post('/api/reconciliation/execute', (req, res) => {
    const { clientId } = req.body;
    if (!clientId) {
      return res.status(400).json({ error: 'El ID de cliente es obligatorio.' });
    }

    const client = clientsState.find(c => c.id === clientId);
    if (!client) {
      return res.status(404).json({ error: 'Cliente no encontrado.' });
    }

    // Unpaid invoices of the client, sorted by Date ascending (oldest first)
    const clientInvoices = invoicesState
      .filter(inv => inv.clientId === clientId && inv.status === 'PENDIENTE' && inv.remainingAmount > 0)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Available advances of the client, sorted by Date ascending
    const clientAdvances = advancesState
      .filter(adv => adv.clientId === clientId && adv.status === 'DISPONIBLE' && adv.remainingAmount > 0)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let totalAmountApplied = 0;
    const generatedApplications: Application[] = [];

    // Pair up matching FIFO entries
    for (const invoice of clientInvoices) {
      if (invoice.remainingAmount <= 0) continue;

      for (const advance of clientAdvances) {
        if (advance.remainingAmount <= 0) continue;
        if (invoice.remainingAmount <= 0) break;

        const maxApplied = Math.min(invoice.remainingAmount, advance.remainingAmount);

        invoice.remainingAmount -= maxApplied;
        advance.remainingAmount -= maxApplied;
        totalAmountApplied += maxApplied;

        if (invoice.remainingAmount <= 0) {
          invoice.status = 'PAGADO';
        }
        if (advance.remainingAmount <= 0) {
          advance.status = 'APLICADO';
        }

        const newApp: Application = {
          id: `APP-${Math.floor(1000 + Math.random() * 9000)}`,
          invoiceId: invoice.id,
          invoiceReference: invoice.reference,
          advanceId: advance.id,
          advanceReference: advance.reference,
          clientName: client.name,
          amountApplied: maxApplied,
          date: new Date().toISOString().split('T')[0]
        };

        generatedApplications.push(newApp);
        applicationsState.push(newApp);
      }
    }

    // Adjust client's balance in state
    client.saldoPendiente = Math.max(0, client.saldoPendiente - totalAmountApplied);
    if (client.saldoPendiente === 0) {
      client.estadoSaldo = 'Al Corriente';
    }

    res.json({
      success: true,
      clientName: client.name,
      amountApplied: totalAmountApplied,
      applications: generatedApplications
    });
  });

  // AI-Powered Suggestion/Audit via Gemini API
  app.post('/api/ai/suggestion', async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.includes("PLACEHOLDER")) {
        // Return a mock structured feedback if API key is not supplied yet
        return res.json({
          suggestion: `### 💡 Sugerencias Estratégicas AI (Previsualización)

*   **Optimización del Flujo:** El cliente **Innovación Digital** mantiene **$12,450.00 MXN** vencidos desde Septiembre de 2023. Se sugiere enviar recordatorio de cobro hoy mismo.
*   **Conciliación Potencial:** Detectamos un potencial de conciliación FIFO inmediata de **$10,400.00 MXN** para **Global Logistics S.A.** utilizando sus anticipos inactivos contra sus saldos vencidos más antiguos.
*   **Eficiencia en Métricas:** Los ingresos del trimestre (Q3) subieron un **12%**, lo cual indica un fuerte desempeño, pero la cartera morosa a +90 días acumula **$12,000.00 MXN**, requiriendo atención prioritaria.`
        });
      }

      // Initialize the official @google/genai client
      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      // Prepare state text for context
      const serializedClients = clientsState.map(c => `- ${c.name} (${c.id}), Categoría: ${c.category}, Saldo: $${c.saldoPendiente}, Estado: ${c.estadoSaldo}`).join('\n');
      const overdueInvoices = invoicesState.filter(i => i.status === 'PENDIENTE').map(i => `- Factura ${i.id} de ${i.clientName}: $${i.remainingAmount} (Emisión: ${i.date}, Urgente: ${i.isUrgente})`).join('\n');
      const unusedAdvances = advancesState.filter(a => a.status === 'DISPONIBLE').map(a => `- Anticipo ${a.id} de ${a.clientName}: $${a.remainingAmount} (Emisión: ${a.date})`).join('\n');

      const systemPrompt = `Eres un auditor financiero Senior de Inteligencia Artificial que trabaja para "Contabilidad Pro".
Analizas la base de datos de clientes, sus anticipos disponibles y sus facturas pendientes para proporcionar sugerencias de cobro y conciliación contable de alto nivel.
Por favor, analiza los siguientes datos y proporciona exactamente 3 puntos concisos, ejecutables, redactados con un lenguaje profesional y pulcro en español:
1) Conciliaciones FIFO inmediatas con mayor potencial monetario.
2) Diagnóstico de clientes con deudas críticas / vencidas que amenazan la liquidez.
3) Acciones concretas sugeridas para mejorar los tiempos de cobro (DSO).

A continuación los datos vivos de la empresa:
### CLIENTES:
${serializedClients}

### FACTURAS PENDIENTES:
${overdueInvoices}

### ANTICIPOS NO APLICADOS:
${unusedAdvances}

Por favor, formatea tu respuesta en un elegante Markdown listo para mostrar en una tarjeta de dashboard corporativo moderna.`;

      const geminiResult = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: systemPrompt,
        config: {
          temperature: 0.7,
        }
      });

      res.json({ suggestion: geminiResult.text });
    } catch (err: any) {
      console.error('Error generating suggestion:', err);
      res.json({
        suggestion: `### 💡 Sugerencias Estratégicas AI (Respaldo Local)

*   **Global Logistics S.A.:** Tiene un saldo potencial reconciliable de **$10,400.00 MXN** mediante la aplicación automática del anticipo **ANT-1022**.
*   **Cartera Morosa en Mora:** El cliente **Innovación Digital** arrastra una mora crítica superior a 90 días. Se aconseja restringir nuevas facturas y activar alertas automatizadas.
*   **Proyección de Ingresos:** Los ingresos generales registran un patrón ascendente de **12%**, reflejando estabilidad de caja en corporativos.`
      });
    }
  });

  // Vite development middleware or production static deployment
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
